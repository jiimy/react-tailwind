## install 


npm i 

## start

npm run start

## 참고
- cra typescript templeate 로 초기 생성되었습니다.
- 코드에 쓰인 이미지 url경로는 23년 7월 29일 기준 31일 뒤에 없어집니다. 
- atomic 패턴이 사용되었습니다.