import React from 'react';
import Hire from './page/hire/Hire';

function App() {
  return (
    <Hire />
  );
}

export default App;
